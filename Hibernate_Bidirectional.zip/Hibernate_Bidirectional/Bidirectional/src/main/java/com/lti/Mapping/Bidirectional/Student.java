package com.lti.Mapping.Bidirectional;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="STUDENT")

public class Student {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName2")
@SequenceGenerator(name="somesequenceName2",sequenceName="student_seq",allocationSize=1)
@Column(name="STUDENT_ID")
private long id;

@Column(name="FIRST_NAME")
private String firstname;

@Column(name="LAST_NAME")
private String lastname;

@Column(name="SECTION")
private String section;

@OneToOne(mappedBy="student",cascade=CascadeType.ALL)
private Address address;

public Student(){}

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getFirstname() {
	return firstname;
}

public void setFirstname(String firstname) {
	this.firstname = firstname;
}

public String getLastname() {
	return lastname;
}

public void setLastname(String lastname) {
	this.lastname = lastname;
}

public String getSection() {
	return section;
}

public void setSection(String section) {
	this.section = section;
}

public Address getAddress() {
	return address;
}

public void setAddress(Address address) {
	this.address = address;
}


}
