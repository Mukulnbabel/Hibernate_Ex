package com.lti.Mapping.Bidirectional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;



@Entity
@Table(name="ADDRESS")
public class Address {
@Id
@Column(name="ADDRESS_ID")
@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="somesequenceName2")
@SequenceGenerator(name="somesequenceName2",sequenceName="address_seq",allocationSize=1)
private long id;

@Column(name="STREET")
private String street;

@Column(name="CITY")
private String city;


@Column(name="STATE")
private String state;

@Column(name="COUNTRY")
private String country;

public String getCountry() {
	return country;
}

public void setCountry(String country) {
	this.country = country;
}

@OneToOne
@PrimaryKeyJoinColumn
private Student student;

public Address(){}

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getStreet() {
	return street;
}

public void setStreet(String street) {
	this.street = street;
}

public String getCity() {
	return city;
}

public void setCity(String city) {
	this.city = city;
}

public String getState() {
	return state;
}

public void setState(String state) {
	this.state = state;
}

public Student getStudent() {
	return student;
}

public void setStudent(Student student) {
	this.student = student;
}

@Override
public String toString() {
	return "Address [id=" + id + ", street=" + street + ", city=" + city + ", state=" + state + ", student=" + student
			+ "]";
}




}
