package com.lti.Mapping.AssignmentOneToMany;

public class Customer {
	private String bankname;
	private int customerid;
	private String customername;
	private String address;
	private int phoneno;
	

}
